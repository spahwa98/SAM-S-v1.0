
public class SharedClass {
	
	public static int otp,lnum;
	public static int getOtp() {
		return otp;
	}
	public static void setOtp(int otp) {
		SharedClass.otp = otp;
	}
	public static int getLnum() {
		return lnum;
	}
	public void setLnum(int lnum) {
		SharedClass.lnum = lnum;
	}
	

}
