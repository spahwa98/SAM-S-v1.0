

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Attendance.AttendanceDao;

@WebServlet("/MarkAttendance")
public class MarkAttendance extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uname = request.getParameter("uname");
		int otp = Integer.parseInt(request.getParameter("otp"));
		
		SharedClass obj = new SharedClass();
		int clnum = obj.getLnum();
		int cotp = obj.getOtp();
		int flag=0;
		
		String lnum = String.valueOf(clnum);
		if(otp==cotp) {
			AttendanceDao dao =  new AttendanceDao();
			
			if(dao.check(uname)==true) {
				dao.markAttendance(lnum, uname);
				flag=1;
				
			}
			else {
				boolean b1 = dao.createRow(uname);
				boolean b2 = dao.markAttendance(lnum, uname);
				flag=1;
			}
		}
		if(flag==1) {
			response.sendRedirect("student_login.jsp");
		}
		else {
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Login Details Not Found or Either You Have Entered Wrong Details');");
			pw.println("location = 'student_login.jsp';");
			pw.println("</script>");
		}
		
		
	}

}
