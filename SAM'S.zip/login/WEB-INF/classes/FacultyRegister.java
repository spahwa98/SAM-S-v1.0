

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import register.RegisterDao;

@WebServlet("/FacultyRegister")
public class FacultyRegister extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String dept = request.getParameter("dept");
		int fid = Integer.parseInt(request.getParameter("fid"));
		String pass = request.getParameter("pass");
		
		RegisterDao dao = new RegisterDao();
		if(dao.checkFaculty(fid)) {
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			out.println("<script type=\"text/javascript\">");
			out.println("alert('You Are Already Registered With Us.. '); ");
			out.println("location='index.jsp';");
			out.println("</script>");
			
			System.out.println("in if");
			
			
		}
		
		else {
			boolean b = new RegisterDao().insertFacultyLoginDetails(fid, name, dept, pass);
			
			if(b==true) {
				System.out.println("in e3");
				response.sendRedirect("registration_success.jsp");
			}
		
		}
		
	}

}
