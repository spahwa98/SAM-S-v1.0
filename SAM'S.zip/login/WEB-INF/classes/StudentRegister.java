

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import register.RegisterDao;

@WebServlet("/StudentRegister")
	public class StudentRegister extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int roll_no = Integer.parseInt(request.getParameter("roll"));
		RegisterDao dao = new RegisterDao();
		
		boolean c = dao.checkStudent(roll_no);
		if(c==true) {
			PrintWriter out = response.getWriter();
			
			response.setContentType("text/html");
			out.println("<script type=\"text/javascript\">");
			out.println("alert('You Are Already Registered With Us..');");
			out.println("location='index.jsp';");
			out.println("</script>");
		}
		
		else {
			
			String name = request.getParameter("name");
			int sem = Integer.parseInt(request.getParameter("sem"));
			String course = request.getParameter("course");
			String section = request.getParameter("section");
			String pass = request.getParameter("pass_1");
			
			
			
			
			boolean b = dao.insertStudentDetails(name, roll_no, course, section, sem, pass);
			
			if(b==true) {
				response.sendRedirect("registration_success.jsp");
			}
			
		}
		
	}

}
