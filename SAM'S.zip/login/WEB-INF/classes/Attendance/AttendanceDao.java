package Attendance;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class AttendanceDao {
	LocalDate date = LocalDate.now();
	String cdate = date.toString();
	public boolean check(String uname) {
		String tname = String.valueOf(uname)+"_attendance" ;
		String sql = "select * from "+tname+" where c_date = ?;";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1, cdate);
			ResultSet rs = pt.executeQuery();
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		}
		catch(Exception e) {
			return false;
		}
		
		
	}
	
	public boolean markAttendance(String lnum, String uname) {
		String tname = String.valueOf(uname)+"_attendance" ;
		String l = "lecture"+String.valueOf(lnum);
		String sql = "update "+tname+" set "+l+"=? where c_date=? ";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1, "P");
			pt.setString(2, cdate);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean createRow(String uname) {
		String tname = String.valueOf(uname)+"_attendance" ;
		String sql = "INSERT INTO "+tname+"(c_date) VALUES(?)";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1, cdate);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
