

import java.io.IOException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TakeAttendance")
public class TakeAttendance extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String lnum = request.getParameter("lnum");
		Random ran = new Random();
		
		int otp = 1000 + ran.nextInt(9000);
		int clnum = Integer.parseInt(lnum);
		
		request.setAttribute("lnum", clnum);
		request.setAttribute("otp", otp);
		
		SharedClass obj = new SharedClass();
		obj.setLnum(clnum);
		obj.setOtp(otp);
		
		RequestDispatcher rd = request.getRequestDispatcher("faculty_attendance.jsp");
		rd.forward(request, response);
		
	}

}
