package register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class RegisterDao {
	
	public boolean insertStudentDetails(String name, int roll, String course, String section, int sem, String pass) {
		String sql_register ="insert into registration values(?, ?, ?, ?, ? );";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement pt = con.prepareStatement(sql_register);
			pt.setInt(1,roll);
			pt.setString(2,name);
			pt.setInt(3,sem);
			pt.setString(4,course);
			pt.setString(5, section);
			
			pt.executeUpdate();
			
			boolean b = insertStudentLoginDetails(roll,pass);
			
			boolean bool = createTable(roll);
			System.out.println(bool);
			
			
			if(b==false) {
				return false;
			}
			
		}
		catch(Exception e) {
			return false;
			
		}
		
		return true;
		
	}
	
	
	
	public boolean insertStudentLoginDetails(int roll, String pass) {
		String sql_login ="insert into login_d values(?, ? );";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement pt = con.prepareStatement(sql_login);
			pt.setInt(1,roll);
			pt.setString(2,pass);
			
			
			pt.executeUpdate();		
			
		}
		catch(Exception e) {
			return false;
		}
		
		return true;
	}
	
	public boolean createTable(int roll) {
		String tname = String.valueOf(roll)+"_attendance" ;
		String sql = "create table "+tname+" (c_date varchar(10), lecture1 varchar(1), lecture2 varchar(1), lecture3 varchar(1), lecture4 varchar(1), lecture5 varchar(1), lecture6 varchar(1), lecture7 varchar(1));";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			Statement st = con.createStatement();		
			
			st.executeUpdate(sql);		
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		
		return true;
		
	}
	
	
	public boolean insertFacultyLoginDetails(int fid, String name, String dept, String pass) {
		
		String sql ="insert into faculty_details values(?, ?, ?, ?)";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			System.out.println("in if");
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setInt(1, fid);
			pt.setString(2, name);
			pt.setString(3, dept);
			pt.setString(4, pass);
			System.out.println("in if1");
			
			pt.executeUpdate();
			
			System.out.println("in if2");
		}
		catch(Exception e) {
			System.out.println(e);
			System.out.println("in if3");
			return false;
		}
		System.out.println("in if4");
		return true;
						
	}
	
	
	
	
	
	
	
	
	public boolean checkStudent(int uname) {
		String sql = "select * from login_d where uname=?;";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, uname);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				return true;
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return false;
	}

	
	public boolean checkFaculty(int uname) {
		String sql = "select * from faculty_details where FID=?;";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, uname);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				return true;
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return false;
	}
	
	
	
	
	
	
	

	

}
