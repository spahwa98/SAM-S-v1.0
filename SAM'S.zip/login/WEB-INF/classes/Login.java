



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.LoginDao;

@WebServlet("/Login")
public class Login extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int uname = Integer.parseInt(request.getParameter("uname"));
		String pass = request.getParameter("pass");
		String opt = request.getParameter("login");
		LoginDao dao = new LoginDao();
		
		if(opt.equals("faculty login")) {
			if(dao.facultyLoginCheck(uname,pass)) {
				response.sendRedirect("faculty_login.jsp");
			}
			else {
				System.out.println("details not found");
			}
		}
		else {
			
			if(dao.studentLoginCheck(uname,pass)) {
				RequestDispatcher rd = request.getRequestDispatcher("student_login.jsp");
				request.setAttribute("SID", uname);
				
				rd.forward(request, response);
			}
			else {
				PrintWriter pw = response.getWriter();
				pw.println("<script type=\"text/javascript\"> ");
				pw.println("alert('Login Details Not Found or Either You Have Entered Wrong Details');");
				pw.println("location = 'index.jsp';");
				pw.println("</script>");
			}
		}
		
	
	}

}
